#!/bin/bash

module unload intel-mkl
module unload intel-mpi
module unload intel
module load intel-parallel-studio
module load slurm_setup

#compilation_mode="trace"
compilation_mode="ofast"

batchrun() {
	/dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/scripts/run.sh 1 micro $1 $2 $3 $compilation_mode
#	/dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/scripts/run.sh 2 micro $1 $2 $3 $compilation_mode
#	/dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/scripts/run.sh 4 micro $1 $2 $3 $compilation_mode
#	/dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/scripts/run.sh 8 micro $1 $2 $3 $compilation_mode
#	/dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/scripts/run.sh 16 micro $1 $2 $3 $compilation_mode
#	/dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/scripts/run.sh 32 micro $1 $2 $3 $compilation_mode
#	/dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/scripts/run.sh 64 micro $1 $2 $3 $compilation_mode
#	/dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/scripts/run.sh 128 micro $1 $2 $3 $compilation_mode
#	/dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/scripts/run.sh 256 micro $1 $2 $3 $compilation_mode
#	/dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/scripts/run.sh 512 micro $1 $2 $3 $compilation_mode
}

/dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/scripts/compile.sh $compilation_mode

# --- RUNNABLE ---
batchrun 512 512 00:30:00
batchrun 1024 1024 00:30:00
batchrun 2048 2048 00:30:00
batchrun 4096 4096 01:00:00
batchrun 8192 8192 06:00:00
# --- ---
