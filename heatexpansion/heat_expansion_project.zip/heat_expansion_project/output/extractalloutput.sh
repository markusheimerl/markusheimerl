find . -name 'output.out' -exec cat {} \; > alloutput.out
