scancel -u di49rib
