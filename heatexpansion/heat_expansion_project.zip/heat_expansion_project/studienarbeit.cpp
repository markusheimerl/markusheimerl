/*
* Copyright 2021 Markus Heimerl, OTH Regensburg, markus (AT) markusheimerl (DOT) com
* Licensed under CC BY-NC 4.0
*
* ANY USE OF THIS SOFTWARE MUST COMPLY WITH THE
* CREATIVE COMMONS ATTRIBUTION-NONCOMMERCIAL 4.0 INTERNATIONAL LICENSE
* AGREEMENTS
*/

#include <mpi.h>
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define TOLERANCE 0.0001
#define MAX_ITERATIONS 1000

//#define DEBUG

#ifdef DEBUG
	#define DEBUGCODE(x) x
#else
	#define DEBUGCODE(x)
#endif

void printMatrix(double* matrix, int rows, int columns, const char* name){
	std::cout << "--- Matrix " << name << " ---" << std::endl;
	for(int i = 0; i < rows; i++){
		for(int j = 0; j < columns; j++){
			std::cout << matrix[i * columns + j] << " ";
		}
		std::cout << std::endl;
	}
	std::cout << "--- ---" << std::endl;
}

void mpi_sleep(int milliseconds){
	// https://www.open-mpi.org/doc/v3.0/man3/MPI_Wtime.3.php
	double starttime = MPI_Wtime();
	while(MPI_Wtime() - starttime < (double)milliseconds/1000.0);
}

int main(int argc, char **argv){

	int rank = 0, size = 0;
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	// --- MATRIX INITIALISATION ---
	int dimT[] = {atoi(argv[1]), atoi(argv[2])};
	
	double* T = new double[dimT[0]*dimT[1]];
	for(int i = 0; i < dimT[0]; i++){
		for(int j = 0; j < dimT[1]; j++){
			T[dimT[1] * i + j] = 0.0;
		}
	}

	double scale = 1000.0;
	T[dimT[1] * 0 + 0] = scale;
	T[dimT[1] * (dimT[0]-1) + (dimT[1]-1)] = scale;
	
	// horizontal
	for(int i = 1; i < dimT[1]+1; i++){
		double val = scale/dimT[1] * (double)((dimT[1]+1)-i);

		T[dimT[1] * 0 + (i-1)] = val;
		T[dimT[1] * (dimT[0]-1) + (dimT[1]-1-(i-1))] = val;
	}
	
	// vertical
	for(int i = 1; i < dimT[0]+1; i++){
		double val = scale/dimT[0] * (double)((dimT[0]+1)-i);

		T[dimT[1] * (i-1) + 0] = val;
		T[dimT[1] * (dimT[0]-1-(i-1)) + (dimT[1]-1)] = val;
	}
	
	double* T_old = new double[dimT[0]*dimT[1]];
	memcpy(T_old, T, dimT[0]*dimT[1]*sizeof(double));

	double* T_new = new double[dimT[0]*dimT[1]];
	memcpy(T_new, T, dimT[0]*dimT[1]*sizeof(double));
	// --- ---
	
	// --- DETERMINE HOW MANY THREADS CAN BE USED (NTHREADS%ROWS HAS TO BE ZERO) ---
	int numberofavailablethreads = 0;
	MPI_Comm_size(MPI_COMM_WORLD, &numberofavailablethreads);
	int numberofusablethreads = numberofavailablethreads;
	while(dimT[0] % numberofusablethreads != 0){numberofusablethreads--;}

	MPI_Comm comm_useable_threads;
	
	if(numberofavailablethreads != numberofusablethreads){
		// exclude unused threads
		MPI_Group world_group;
		MPI_Comm_group(MPI_COMM_WORLD, &world_group);
		MPI_Group new_group;
		int ranges[1][3] = {{numberofusablethreads, size-1, 1}};
		MPI_Group_range_excl(world_group, 1, ranges, &new_group);
		MPI_Comm_create(MPI_COMM_WORLD, new_group, &comm_useable_threads);
		if (comm_useable_threads == MPI_COMM_NULL){
		   MPI_Finalize();
		   exit(0);
		}
	}else{
		comm_useable_threads = MPI_COMM_WORLD;
	}
	
	float rptf = (float)dimT[0]/(float)(numberofusablethreads);
	int rowsperthread = ceil(rptf);
	
	if(rank == 0){
		std::cout << "Usable threads for calculation: " << numberofusablethreads << std::endl;
		std::cout << "Rows per thread: " << dimT[0] << "/" << numberofusablethreads << " = " << rowsperthread << std::endl;
	}
	// --- ---
	
	// --- SET CALCUALTION VARIABLES ---
	double error = 1.0;
	int n_iteration = 1;
	double c = 0.1;
	double delta_s = 1.0 / float(dimT[0]-1);
	double delta_t = ((delta_s*delta_s)/(4*c)); // delta_t has to be smaller or equal to (delta_s^2)/(2*c)
	// --- ---

	double starttime = MPI_Wtime();

	while(error > TOLERANCE && n_iteration < MAX_ITERATIONS){

		DEBUGCODE(std::cout << "--- Iteration: " << n_iteration << " ---" << std::endl);

		// --- CALCULATE ROWS ---
		for(int j = 1; j < dimT[1]-1; j++){
			for(int i = rowsperthread*rank; i < rowsperthread+(rowsperthread*rank); i++){
				if(i == 0 || i == (dimT[0]-1)) continue; // calculate linearly
				// jakobi																								
				// T[dimT[1] * i + j] = (1/k) * ( (T_old[dimT[1] * (i-1) + j] + T_old[dimT[1] * (i+1) + j]) / (dx*dx) + (T_old[dimT[1] * i + (j-1)] + T_old[dimT[1] * i + (j+1)]) / (dy*dy) );
				T[dimT[1] * i + j] =  T_old[dimT[1] * i + j] + c * (delta_t/(delta_s*delta_s)) * (T_old[dimT[1] * (i-1) + j] + T_old[dimT[1] * (i+1) + j] - 4*T_old[dimT[1] * i + j] + T_old[dimT[1] * i + (j-1)] + T_old[dimT[1] * i + (j+1)]);
				//T[dimT[1] * i + j] =  0.25 * (T_old[dimT[1] * (i-1) + j] + T_old[dimT[1] * (i+1) + j] + T_old[dimT[1] * i + (j-1)] + T_old[dimT[1] * i + (j+1)]);
			}
		}
		// --- ---

		// --- RECEIVE CALCULATIONS BY THREADS ---
		MPI_Allgather(T+rowsperthread*rank*dimT[1], rowsperthread*(dimT[1]), MPI_DOUBLE, T_new, rowsperthread*(dimT[1]), MPI_DOUBLE, comm_useable_threads);
		// --- ---
		
		// --- DETERMINE ERROR ---
		double maximum = 0.0;
		for(int i = 0; i < dimT[0]; i++){
			for(int j = 0; j < dimT[1]; j++){
				double sub = fabs(T_new[dimT[1] * i + j] - T_old[dimT[1] * i + j]);
				if(sub > maximum) maximum = sub;
			}
		}
		error = maximum;
		// --- ---
		
		memcpy(T_old, T_new, dimT[0]*dimT[1]*sizeof(double));
		n_iteration++;
		
		//if(rank == 0)printMatrix(T, dimT[0], dimT[1], "T");
		//mpi_sleep(1000);
		
		DEBUGCODE(std::cout << "--- ---\n" << std::endl);
	}
	
	double endtime = MPI_Wtime();
		
	if(rank == 0){
		// --- PRETTY PRINT RESULT ---
		std::cout << std::endl;
		std::cout << "--- Final result at iteration " << n_iteration << " after " << endtime - starttime << " seconds using " << numberofusablethreads << " parallel processes ---" << std::endl;
		//printMatrix(T_new, dimT[0], dimT[1], "T_new");
		// --- ---	
	}
	
	MPI_Finalize();
	return 0;
}
