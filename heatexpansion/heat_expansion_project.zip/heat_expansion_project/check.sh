#!/bin/bash
squeue --user di49rib
