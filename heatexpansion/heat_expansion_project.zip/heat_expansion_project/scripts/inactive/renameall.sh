for f in *; do mv "$f" "${f%}_test"; done;
