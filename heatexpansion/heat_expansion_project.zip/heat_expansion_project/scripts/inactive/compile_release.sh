mpiCC -o ~/Markus/Relaxationsverfahren/output/studienarbeit.out ~/Markus/Relaxationsverfahren/studienarbeit.cpp
