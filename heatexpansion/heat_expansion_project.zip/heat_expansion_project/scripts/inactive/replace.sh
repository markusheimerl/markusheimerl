sed -i 's!old-text!new-text!g'

# ! can also be /
