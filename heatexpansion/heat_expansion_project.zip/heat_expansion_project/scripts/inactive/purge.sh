rm -r *
mkdir compiled
touch purge.sh
chmod 755 purge.sh
echo $'rm -r *\nmkdir compiled\ntouch purge.sh\nchmod 755 purge.sh\necho $'rm -r *\\nmkdir compiled\\ntouch purge.sh\\nchmod 755 purge.sh' > purge.sh' > purge.sh
