#!/bin/bash

#module load itac - this is deprecated after June 2021 update https://doku.lrz.de/display/PUBLIC/Spack+Modules+Release+21.1.1
# and replaced by module commands below
module unload intel-mkl
module unload intel-mpi
module unload intel
module load intel-parallel-studio

module load slurm_setup
#module load mpi.intel

#rm /dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/output/compiled/studienarbeit.out
#/dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/scripts/compile.sh

# n_tasks partition x_dim y_dim
/dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/scripts/run.sh $1 $2 $3 $4 $5 $6
