#!/bin/bash

if [[ $1 == "trace" ]]
then
	mpiCC -trace -g -tcollect -o ~/Markus/Relaxationsverfahren/output/compiled/studienarbeit.out ~/Markus/Relaxationsverfahren/studienarbeit.cpp
elif [[ $1 == "ofast" ]]
then
	mpiCC -Ofast -o ~/Markus/Relaxationsverfahren/output/compiled/studienarbeit.out ~/Markus/Relaxationsverfahren/studienarbeit.cpp
else
	echo "Invalid compilation mode"
	exit 1;
fi

chmod -R 777 ~/Markus/Relaxationsverfahren/output/compiled
