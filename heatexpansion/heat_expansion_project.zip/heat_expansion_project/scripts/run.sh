#!/bin/bash

# rm -r /dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/output/$3x$4_$1_$2_$6
mkdir /dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/output/$3x$4_$1_$2_$6

sbatch <<EOT
#!/bin/bash
#SBATCH -J $3_$1_$6
#SBATCH -o ./output.out
#SBATCH -e ./error.err
#SBATCH -D /dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/output/$3x$4_$1_$2_$6
#SBATCH --mail-type=NONE
#SBATCH --time=$5
#SBATCH --no-requeue
#SBATCH --export=NONE
#SBATCH --get-user-env
#SBATCH --account=pr92ki
#SBATCH --partition=$2
#SBATCH --ntasks=$1

mpiexec -n $1 /dss/dsshome1/00/di49rib/Markus/Relaxationsverfahren/output/compiled/studienarbeit.out $3 $4
EOT
