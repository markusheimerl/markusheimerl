# module load itac - deprecated https://doku.lrz.de/display/PUBLIC/Spack+Modules+Release+21.1.1
module unload intel-mkl
module unload intel-mpi
module unload intel
module load intel-parallel-studio

module load slurm_setup
traceanalyzer &
